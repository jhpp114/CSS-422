The flow of these images are

1. Proper_Input_Starting_Adr(2)
2. After_Convert_Input
3. Proper_Input_Ending_Adr
4. After_Get_Ending_Input
5. AfterGetAllInput
